# the-sound-of-love

  I heard the sound of love 
  and I didn't like it.

  I know so many songs
  after thousands of hours
  and have so few memories
  to attach to them. So maybe
  these stories will be something
  I live through instead.

  Love...
  
  
