
/*

FORMS OF LOVE
heartbreak
romantic
familial
longing
self

*/

let love = [
  {
    "c": `Told this girl that I love her, and she said she had the same feelings towards me. We held each other and kissed, life has never been so perfect.

A few days later she said that we shouldn't date.

This song is every emotion ever felt in that time-fram;, both pure ecstasy and pure heartbreak.`,
    "v": "iB7E1D_3Na4",
    "s": "Ladies and Gentlemen We Are Floating in Space – Spiritualized",
    "t": "heartbreak"
  },
  {
    "c": `I spent 22 years with a lovely girl. I loved her but now I know I didn't love her in the way that I needed. When we broke up she told me that I didn't have any good memories of our time together. I do but I just don't express them well when face to face with tears. I still remember those early days in London. I still remember the look on your face when I smuggled those pills into your first rave. I still remember the way you used to kiss me amidst the lazers while high on E and I certainly remember the night that I played this song to you. Over and over again while you sat on my bed smoking joint after joint with me and laughing at how I sung this song to you, on loop, for what I remember to be an entire night of happiness that I still remember vividly to this day. I will love you till I die and I will.. but I am sorry it didn't take the pain away. At that moment I was confident it would. My heart was in the right place. I know for that night your heart was there too. Please don't think I don't have any happy memories of you.`,
    "v": "iB7E1D_3Na4",
    "s": "Ladies and Gentlemen We Are Floating in Space – Spiritualized",
    "t": "romantic"
  },
  {
    "c": `For GARRETT, a guy from Colorado/Maryland who showed me this song and also showed me what it's like to truly connect with someone. Soul to soul, mind to mind, not like the other ones in the past. I miss your voice, your sleepy "hellos", and your giggles. I miss your words, and the way you put your thoughts together. I miss your little quirks, and even the ones that would annoy me sometimes. I hope that as you slipped away you felt what this songs you showed me made you feel, but also my love. I hope you are eternally jamming out. One day we will meet again, to tell you that I indeed love you too. Rest in my heart.`,
    "v": "iB7E1D_3Na4",
    "s": "Ladies and Gentlemen We Are Floating in Space – Spiritualized",
    "t": "romantic"
  },
  {
    "c": `i first discovered this beautiful song with someone i loved, they shared it with me, and it felt so intimate and nice i fell asleep to it throught the phone. learned that she was in a relationship and my heart sunk. every now and then i come back here to listen to this masterpiece, remember the times she and i shared, remember how she'd take care of me. we're now friends, but my heart keeps wondering where we could've been now if she were mine.`,
    "v": "iB7E1D_3Na4",
    "s": "Ladies and Gentlemen We Are Floating in Space – Spiritualized",
    "t": "heartbreak"
  },
  {
    "c": `Been hearing this song in my head thinking about the only person I've ever had mutual happiness with and loved more than anyone.

A girl named Lucia. The highlight of my life. When we met, we were seeing each other at our worst, but we connected on a level I've never found in my life. We were both in bad situations but we found so much happiness in each other. From holding hands everywhere, to the little tug of war battles in the stores and elsewhere, to cuddling in bed to watch videos on her phone, to feeding ducks and swinging in the park, and so many more things, every one of them special to me.

I was there for her since the moment we met, and I always will be.

But I said too many dumb things, and things that got misunderstood. I got emotional over small things too much because of my past. I focused too much on being happy and making her happy, so much so that I neglected other priorities which would have helped us both, like making more money so we could move closer to her friends and family. Ultimately that led to her feeling trapped and isolated and emotionally wrecked.

She's young and still figuring a lot of things out, so I don't blame her for anything. I understand the things that made her feel how she felt to leave. I do wish she hadn't let other people get in the way and second-guessed who I am though. She's the only person I've never told a lie to, but I couldn't convince her to trust and believe me over people who speak from a position of "authority" or who have their own motives. But with time, maybe eventually she'll realize these people were wrong.

I wish I could just have a chance to fix myself and make up for my mistakes and try again. I would give anything for that.

Now I feel like I don't matter at all. Every day I'm thinking of her. I wish I wasn't such a broken human being. If only I'd thought of the right words...

I wonder if she misses me as much as I miss her.`,
    "v": "Rel8ZWkNNlM",
    "s": "Pictures of You – The Cure",
    "t": "heartbreak"
  },
  {
    "c": `The same guy who has loved me since I was 16 years old dedicated this song to me. I'm 43 now and no one will ever love me or understand me the way he does.`,
    "v": "Rel8ZWkNNlM",
    "s": "Pictures of You – The Cure",
    "t": "heartbreak"
  },
  {
    "c": `This reminds me of my late boyfriend Chris. He passed away from suicide and the last I saw him was in December. The last I kissed him, hugged him, felt his presence..He lived with an abusive father and had no mother because she had lost her battle to suicide when he was in middle school. He cried for a mother and craved that bond and love. I was the only on to keep him afloat for years until the one last fight he had with his father..he just couldn't take it anymore.
The last thing I got from him was a message at 1:38 a.m. “ i love you so much .. and don’t ever think i don’t” i woke up to a flood of messages asking if I had heard the news, am I okay, and if I’m alive..
I thought it was one of those late night messages, but his best friend called and he said “Elizabeth, promise me you will be strong but.... Chris..shot himself last night” and i hung up Immediately.
I couldn’t process it , my heart wasn’t beating, my hands were shaking and i screamed like I’ve never screamed before.I called him well over 40 plus times but..he never answered.

He passed away on January 5th 2019.

He had a polaroid camera and i have a picture of him at the lunchroom and I keep it at my bedside at all times. When he was laid to rest they buried him with a suit that he wore when we went to our last prom,the guitar necklace I gave him for Christmas that December and finally the polaroid picture he took of me at the lockers and they had put it in his pocket close to his heart.

I’ll see you soon my love,my goofball and all.
This song goes out to you Chris and to all who suffer loss but are brought together out of love.
🌻`,
    "v": "Rel8ZWkNNlM",
    "s": "Pictures of You – The Cure",
    "t": "heartbreak"
  },
  {
    "c": `You gave every song to me, then you gave the same songs to another. But hey: from life, you want to make alot of money and feel dead inside. Bon courage, c***.`,
    "v": "U43AA5meBXg",
    "s": "Birds – Electrelane",
    "t": "heartbreak"
  },
  {
    "c": `remember when you loved me in the morning. i miss you forever. goodbye my love`,
    "v": "U43AA5meBXg",
    "s": "Birds – Electrelane",
    "t": "romantic"
  },
  {
    "c": `He’ll never see this so I’m going to say it. This song makes me think of you and I love you, even if you’re too scared to say it back, it doesn’t matter to me`,
    "v": "ZDfXdsKwMMI",
    "s": "Orange Peeler – Horse Jumper of Love",
    "t": "romantic"
  },
  {
    "c": `I played this song while I was having a car ride with my dad and he loved it and it kinda became our song
he passed away a month ago and it hurts so much to listen to it but it brings so much memories
rest in peace my love I'll miss you forever`,
    "v": "wjHgiSx0RNQ",
    "s": "Robbers – The 1975",
    "t": "familial"
  },
  {
    "c": `I come back to this song every time I feel that strange need for reckless loving.

I'm in a relationship and we're both very happy, very safe people. However, sometimes I want what this video shows... that extreme risk, and that reckless love. That jolt of excitement, that rush of a kiss after something insane just went down... I'd never risk my life, nor my partners for a thrill, but damn. This video makes me think.`,
    "v": "wjHgiSx0RNQ",
    "s": "Robbers – The 1975",
    "t": "longing"
  },
  {
    "c": `My girlfriend and I really adored this song. It speaks a lot about our love, how we stood despite the differences we have from our family backgrounds, especially religion. Our family will despise us, people will, but guess that's what love is, to stand and fight together despite storms.

No one can rob us of our love for each other, and no matter what people will say, she'll always look cool.`,
    "v": "wjHgiSx0RNQ",
    "s": "Robbers – The 1975",
    "t": "romantic"
  },
  {
    "c": `Someone I loved with all my heart once sent me this song. It became a theme for us and it was beautiful. But time eroded those feelings and showed the true rock beneath and the love was untrue. For a long time I could not listen to this song without feeling such a great loss that my soul cried out. It still hurts, but I can endure it now. Amazing how much clarity pain can bring.`,
    "v": "ge3cf-AEZEs",
    "s": "Boats and Birds – Gregory and the Hawk",
    "t": "romantic"
  },
  {
    "c": `“There’s a time where we get old and replaced the things we once loved with other things, when you realize the stuff you left behind in your childhood.. you remembered them and started crying. Nothing’s more important than love”`,
    "v": "MSepOYJxB64",
    "s": "Wet Hands – C418",
    "t": "longing"
  },
  {
    "c": `I never new i could enjoy 10 hours of remembering my depressing past that i forgot about and also the horrible mistakes i had done that made me miserable and totally lonely and this helped me to relax and enjoy for i will have happiness until i think about my mistakes and sins that i did and i regret doing because it causes me more depression and sadness and heartbreak and tears that fallen from my eyes, my eyes that saw what i have done in the past that almost ruined my life, but i will never forget that no matter what will i do, someone is always there to forgive you.

Me and my longest comment`,
    "v": "MSepOYJxB64",
    "s": "Wet Hands – C418",
    "t": "self"
  },
  {
    "c": `Come. Have a seat. Don't worry, it's alright. You can stay here as long as you need. In the meantime just relax, get comfortable. I know it's been difficult these past few years but hey, at least we have this opportunity to watch the sun set over the horizon. It's been a long run. Maybe tomorrow we can do this again.`,
    "v": "MSepOYJxB64",
    "s": "Wet Hands – C418",
    "t": "self"
  },
  {
    "c": `This was the first song that played when I played Minecraft with my dad the first time. I remember having so many good times with him, just fooling around, building things, and having fun. He committed suicide 5 years ago. When I started up one of our Minecraft worlds on our Xbox, I cried so hard. Just goes to show that even music, game music at that, leaves a mark on people.`,
    "v": "MSepOYJxB64",
    "s": "Wet Hands – C418",
    "t": "self"
  },
  {
    "c": `I haven't cried in years. But this finally did it.`,
    "v": "MSepOYJxB64",
    "s": "Wet Hands – C418",
    "t": "self"
  },
  {
    "c": `you hate it all and yet you still use shampoo..`,
    "v": "M_5ysvE_GiE",
    "s": "Shampoo Suicide – Broken Social Scene",
    "t": "self"
  },
  {
    "c": `My ex husband dedicated this song to me. We separated years ago, but we still had a good bond because of the kids. My first love. My best friend. He recently passed away in October leaving behind 2 little girls, Emma & Lua. RIP Kyle, I’ll always be your yellow bird!`,
    "v": "54Z2zfr1mrI",
    "s": "Poison Oak – Bright Eyes",
    "t": "romantic"
  },
  {
    "c": `This song reminds me of me and my brother fighting in our feild... He was much older would always win, and would leave me to walk home alone with bloody knees and hands... Now he's dead and I put his ashes out to that field... Not sure if i feel liberated or lonely...`,
    "v": "54Z2zfr1mrI",
    "s": "Poison Oak – Bright Eyes",
    "t": "familial"
  },
  {
    "c": `Now I'm on the other side guys, love is beautiful,`,
    "v": "54Z2zfr1mrI",
    "s": "Poison Oak – Bright Eyes",
    "t": "self"
  },
  {
    "c": `Me and my best friend spent a long time getting this right. He is dead now and this song makes me think of him and hurting`,
    "v": "54Z2zfr1mrI",
    "s": "Poison Oak – Bright Eyes",
    "t": "self"
  },
  {
    "c": `I love her. I know it now. The distance scared me so I distanced myself from her and treated her special while seeing other people as just bodies to satiate that lust. But she's not just another face. Now I'm in too deep and I don't know if I can cut off the people I see as bodies after breaking her heart. I know I can but it's easier this way because I'm not hurting her I guess.
I should leave the meaningless sex and flirting behind and love her, but I'm scared.
She's not just another face. I'm scared I'll stop feeling this way and hurt her.`,
    "v": "WMrU3f5QQR8",
    "s": "How Do I Tell A Girl I Want To Kiss Her? – Modern Baseball",
    "t": "longing"
  },
  {
    "c": `Story time kiddos! Y’all don’t have to read but if you do then I fucking applaud you for it. I’m 19 now and high school feels like a distant memory now but it’s also all very fresh. I was best friends with the same girl all the way from back in second grade and we talked constantly and it was fucking great. Along comes sophomore year and my parents divorced, and of course me already suffering from depression went into a whole tail spin. When my mom and I moved into our new apartment the previously mentioned friend helped me move my stuff into my new room in the attic when I finally and genuinely asked her if she wanted to be together and she said yes with this giggle that lit up my world and this look in her eyes that melted my heart. A week later we shared our first kiss and it is a moment that has always been vivid in my mind and I cherish it every day. As time passed we spent every moment we could together along with sordid friends and people from clubs at school, she was in marching band so of course I went to every game so I could see her play and I was in musicals so she always came to my shows. Fast forward to today when I wish I could say this has a happy ending. That we are still together and moving in and things are still amazing but no. Painfully that’s not the case. The fact that I just found this song reminded me of just how bad I fucked it all up. After two and a half years I left her and it was the dumbest thing I ever did. It was two weeks from prom after she already said yes, a week after my senior show where I told her backstage that everything would be ok, a month after making plans to be together forever. Like an idiot I broke it off and whether it was out of fear or a need to get away for a while I don’t know. We still talk and we are at the same college now. Things aren’t the same and I acted like an asshole for a while after which only hurt her more. Now she’s with a new guy and they are getting along amazingly and I’m happy for her. Even though it means that even if I wanted we can’t hang out really cause she’s too busy between work and the boy friend. Like i said though, not a day goes by where I don’t think of her or her smile, that giggle, listening to her sing while I’m pretending to sleep on a road trip, swimming in the summer, vacations in the south, naps after school, Christmas Eve in each other’s arms, it’s all still there and it hurts but it’s beautiful. So yea that’s a thing. Enjoy the song everyone, keep listening to music it’s a helluva thing for us all.`,
    "v": "WMrU3f5QQR8",
    "s": "How Do I Tell A Girl I Want To Kiss Her? – Modern Baseball",
    "t": "longing"
  },
  {
    "c": `This songs remains me of a girl I used to be in love with. We were on the same class room during the whole high school, it was not until the second semester when we started to talk. She was everything I dreamt before, then I had this friend who managed to exchange Facebook passwords with her so there was a conversation of her telling her best friend that she had a crush on me, I was the lonely teenager that used to be drunk every weekend while blasting hardcore stuff with his friends, to read that chat was like "damn, I'm actually something for someone else that it's not my mom". We spent whole nights talking/texting and then we looked like zombies the day after and since we always sat next to each other I remember my hands always touching her hair lol I loved her more than anything, I always told her that I loved her but for some strange reason even though I knew she felt something she never wanted to be something more, high school was over and I was supposed to kiss her the last day but her mom came to pick her up and everything went to shit. Some days later she was having her birthday, I wrote her but I got some fucked up shit in response then I decided that it was not healthy for me to love her, we stopped talking and we became strangers to each other, couple years ago I met her in the downtown but again we just passed over each other like we never met before, I still think about her even tho it's 4 years now since we left each other. I wonder if she remembers...`,
    "v": "WMrU3f5QQR8",
    "s": "How Do I Tell A Girl I Want To Kiss Her? – Modern Baseball",
    "t": "longing"
  },
  {
    "c": `I always end up listening to this song, but i never realised till about a week ago that what is going on in this song is actually happening to me in real life. I need this girl more than she needs me, and im constantly thinking about her, but I know i'll never be able to go there from what happened in the past. Shes like my rock and has been since day 1. Shes amazing, but everything between us sucks now.`,
    "v": "WMrU3f5QQR8",
    "s": "How Do I Tell A Girl I Want To Kiss Her? – Modern Baseball",
    "t": "longing"
  },
  {
    "c": `my crush kissed me last night and literally this song came through my head because he was like " and what if i tell you that i really wanna kiss you " and it was so cute i just can't ughhhhhhh
be happy with me pls
`,
    "v": "WMrU3f5QQR8",
    "s": "How Do I Tell A Girl I Want To Kiss Her? – Modern Baseball",
    "t": "romantic"
  },
  {
    "c": `This song reminds me of the boy I wish I could of have. He liked me a lot and I was too afraid to tell him how I felt. I have always adored him and always told him I didn’t like him because all I wanted to do was protect him and I. I didn’t want to hurt him or ruin our friendship. I was all on his mind, home coming night he tried  to kiss me. I got scared and backed away. He then fell for my best friend and forgot about me and started hating me, she lied to me and got with him. The way he looked at you made you feel like you didn’t need anyone else. I never took someone for granted as much as much in my life. I wish I never ignored the signs. He made me laugh and smile more than anything else in this world. I miss him STILL to this day.`,
    "v": "WMrU3f5QQR8",
    "s": "How Do I Tell A Girl I Want To Kiss Her? – Modern Baseball",
    "t": "longing"
  },
  {
    "c": `This song will always mean so much to me. It reminds me of the girl I long for, my best friend. Of course she doesn't know it yet. But she will. I promise I will tell her someday. Shes preoccupied at the moment dating an asshole jock. I still listen to her talk about him and about how much she likes being liked. I dont really think she likes him though. I think she just likes the idea of being loved like most girls do. But I would love her more than Wyatt ever could. I honestly just want her to be happy. She deserves it. And I definitely dont deserve her. That's why I'll keep my distance. Not give her any hints about my feelings and just let her be. I'll just be her best friend like I'm supposed to. But I'll still be waiting.`,
    "v": "WMrU3f5QQR8",
    "s": "How Do I Tell A Girl I Want To Kiss Her? – Modern Baseball",
    "t": "longing"
  },
  {
    "c": `I randomly thought of this song tonight. I remember listening to this song and crying to it after my first breakup. He was my best friend and he broke it off. I still find it unbelievable. He was so careless and quick to move on. I will never forgive him. But I still miss the person who he used to be. Even in my new relationship, I dont think I'll get over him.`,
    "v": "WMrU3f5QQR8",
    "s": "How Do I Tell A Girl I Want To Kiss Her? – Modern Baseball",
    "t": "heartbreak"
  },
  {
    "c": `This used to be my ex and mines song. We’d listen to it all the time, every time either of us were going through something.  We’d always sing every word to each other because we knew it so effortlessly. Sometimes we’d even hum it just because. 

We aren’t together anymore. And though I think it was for the best for both of us, I can’t just forget all the memories. All the late night calls, times we cried laughing, and every single “i love you” said to each other. It’s so weird seeing him pass in the halls everyday and acting like we’ve never met, despite the years worth of memories we share. Someone who used to be my world is now a complete strangers. 

Despite us living our separate lives now, I’ll still come back and listen to this song every once in a while. Not because I want to remember us or him, but because I want to relive the feeling that this song always made me feel. Pure comfort and safety.`,
    "v": "WMrU3f5QQR8",
    "s": "How Do I Tell A Girl I Want To Kiss Her? – Modern Baseball",
    "t": "longing"
  },
  {
    "c": `2 years ago I would listen to this song and many other similar songs while riding in the back seat in the car looking onwards on deep forest, there was something utterly peaceful and tranquil about it while just thinking about my crush at the time. Now two years later I’m certain she doesn’t like/never has and have all but given up hope but I still listen and look back at this song, many others and that time as a whole and feel a sort of nostalgic melancholy. I mean I was just a freshmen with many years ahead of me so eager and careless listening to songs like this imagining me and her walking through the beautiful woods. All I can think of now is how years down the road I’ll listen to this song again and my youth and everything will hit me again and think about how naïve and stupid I was. Idk man this song just means so much to me it gives me such a weird fucking feeling, lol.`,
    "v": "WMrU3f5QQR8",
    "s": "How Do I Tell A Girl I Want To Kiss Her? – Modern Baseball",
    "t": "longing"
  },
  {
    "c": `This song crushes me... 
My friend wherever he is, I hope to see him again. The last time I waited to see him was 7 long years, now that we are both adults I can't simply handle not seeing him for months. All we had was a small kiss to the cheek and what followed right after was just a lovely feeling of intimacy and affection over one another. That week I felt noticed and important for someone. Those days were months ago and he disappeared off of the map. The only thing I can do is hope to see him...`,
    "v": "pBMwwJMkcRA",
    "s": "The Predatory Wasp Of The Palisades Is Out To Get Us! – Sufjan Stevens",
    "t": "longing"
  },
  {
    "c": `I remember the first time I heard this song. A dear friend, a Missionary from The Church of Jesus Christ, told me I would love it. 

That was a glorious time, and we were sharing what could be described as a childhood in shared rebirth. "Lamb of God, we sound the horn, to us your Ghost is born" moved me and made me aware of how much I love the verse, "For unto us a child is born, unto us a Son is given", and now I love this song.`,
    "v": "pBMwwJMkcRA",
    "s": "The Predatory Wasp Of The Palisades Is Out To Get Us! – Sufjan Stevens",
    "t": "longing"
  },
  {
    "c": `We were in love indeed, so sad what happened between me and him, we were best friends, a little bit of miss understanding, and that was it. I'll never forget that beautiful days we spent together. It's like finally finding your half missing soul, only to lose it in one month period.
Feels horrible. 
This song (aside from the gay part) describes it all..`,
    "v": "pBMwwJMkcRA",
    "s": "The Predatory Wasp Of The Palisades Is Out To Get Us! – Sufjan Stevens",
    "t": "longing"
  },
  {
    "c": `You're gone now, but your love will exist infinitely through this song. We are in love somewhere in the past, whispering to each other, forever in love. `,
    "v": "pBMwwJMkcRA",
    "s": "The Predatory Wasp Of The Palisades Is Out To Get Us! – Sufjan Stevens",
    "t": "longing"
  },
  {
    "c": `In 2015 I had a close friend and pretty much we share similar interests. We often show each other newfound songs and movies. He had a bad childhood trauma and sadly didn't tell me about it, probably afraid or for any other unknown reasons. But he told his past to a girl he was being close and in the end the girl didn't want to see or talk to him anymore.

All of this and the past trauma brought him to end his own life, and since it's too sudden I can't really processed anything and just ask myself, "Why?"

I kept some of his personal belongings and one of them is his notebook.
He wrote the lyrics to this song. It's quite weird since I thought the lyrics sounds gay (not insulting, I'm not straight too but not into gay relationship). I didn't even bother looking for the song in google, afraid of the emotional surge and all.
2018 and watched Call Me By Your Name and got caught by Sufjan's songs (yeah I know it's too late) and search his other songs on youtube and realized one of them is this song, the one that my friend wrote on his notebook (lyrics on notebook didn't mention Sufjan's name and only had the second part of the song). 

Some times I wish my friend wrote the lyrics for me, but weirdly he never made me listen to this song, probably afraid of being labeled as gay. I never had problem with gay people and he knew it too.

So for now I always thought of him whenever I heard or played this song. Sufjan Stevens is a genius and I'm glad I live in the same time as his works.

And for you Silly Wabbit, happy 34th birthday. I hope you are happy wherever you are.
I love you.

P.S. Sorry for bad English. I feel better now, but still mad at my friend for leaving this world to me. Can't really get mad cause I really like him. It's quite saddening that soul mates can only be together for a brief period of time. 
Whoever read this I hope you're living a happy life too. Live the moment. Believe in your close friend. Tell them you love them.`,
    "v": "pBMwwJMkcRA",
    "s": "The Predatory Wasp Of The Palisades Is Out To Get Us! – Sufjan Stevens",
    "t": "longing"
  },
  {
    "c": `I remember the first time I heard this song.  I was in the car with my ex and this song resonated with me so much.  To the point of tears.  I looked over at my ex and they didn’t even respond.  They actually hated the song and it was at that moment when I realized that we were never meant to be.  That they would never follow me into the dark.  Flash forward to 4 years later, and I had a first date with someone very special to me. We went to a bar and they had karaoke.  Wouldn’t you know, this was the song he had chosen to sing!  That special someone is my now husband and we’re expecting our first child in May! So don’t give up hope! There is someone for you!`,
    "v": "NDHY1D0tKRA",
    "s": "I Will Follow You Into The Dark – Death Cab For Cutie",
    "t": "romantic"
  },
  {
    "c": `Almost 8 years since my best friend committed suicide, we sang this together a lot, it made sense since we had a suicide pact that if they other killed themselves than we would follow suit, working ad a deterant, i guess one day the demons got to loud and she took her own life, i tried to follow suit and swollowed all my sleeping pills, but i was found seizing on the floor by my mother who heard me, and i was rushed to the hospital i had my stomach pumped and was stabalized, and i was sent to a metal health institution, i was blaming myself for not being able to follow her and that i had made a promise, i took me 5 years for my counsellor to get it through to me that if i had followed through with the pact, then i would have broken the very spirit that the pact was formed on, she wanted me to live and if i had killed myself then i would be betraying her. That was a hard pill to swallow, im still not in a good place but i have go forge on, to keep her memory alive, her mom finally cleaned out her room, and she sent me a bunch of the love letters that she had written me, honestly i didnt know she felt the same way, im still trying to force the thought that maybe if i had just told her how i felt, maybe we would be together and happy today, my heart still aches but ill keep going i have to. I love you elizabeth, and theres not a damn thing you can do about it..`,
    "v": "NDHY1D0tKRA",
    "s": "I Will Follow You Into The Dark – Death Cab For Cutie",
    "t": "romantic"
  },
  {
    "c": `i sing this song to my cat who is getting pretty old. i’ve lived my entire life with her, and i honestly love her more than anyone in the world. living without her won’t really be living.`,
    "v": "NDHY1D0tKRA",
    "s": "I Will Follow You Into The Dark – Death Cab For Cutie",
    "t": "romantic"
  },
  {
    "c": `my soulmate died a day before my birthday. he was in love with me, and it was the purest love anyone had ever given me. (i’ve only experienced toxic love before) which made me too afraid to allow myself to love him back. i didnt know how to accept such love im not used to. he always asked me to take a chance with him, and i always replied “im too afraid to lose you and i cant afford that” thing is, he never knew i was more afraid to love him than to lose him. but in losing him, i realized i’ve loved him. i loved him. i love him. but i never got to tell him that, i never got to tell him that when i asked him if he ever met someone he genuinely wanted to spend the rest of his life with that i hoped i’d be his answer because he was mine. he was someone i saw myself wanting to spend the rest of my life with... but now every year his death anniversary is a day before my birthday reminding me of how he never got to celebrate it with me like he said he would. hope when our souls reunite one day, i tell him how much i loved him. tell him i’m sorry that his last text msg was “please reply”, i’m sorry i watched my phone ring without picking up. i’m sorry that our last phone call was short. i’m sorry i didn’t hold him tighter the night that was our last. your soul is with me always. i carry you with me everywhere i go and no time would ever erase or replace you. you’re a part of me, and one day ill be able to tell you myself.

he died in his sleep.

rest your heart and soul in peace, my angel Hussam. until we meet again.`,
    "v": "NDHY1D0tKRA",
    "s": "I Will Follow You Into The Dark – Death Cab For Cutie",
    "t": "romantic"
  },
  {
    "c": `This song reminds me of my great grandparents, after 65 years of marriage and growing up together my grandmother went into the hospital for a routine checkup she suddenly had a stroke and ended up in palliative care and an hour later we were saying our goodbyes when my uncle wheeled in my grandfather he screaming at the top of his lungs that it was supposed to be him first and if his legs still worked he'd carry her through the gates of the holy land himself because it was what she deserved, it was the most heart breaking thing I have ever heard in my life he kept saying over and over that he loved her and after 65 years he had still loved her so very much since before they were kids, to this day I still hear him crying, she was completely unresponsive but when she passed she opened her eyes one last time and looked at him and he said he loved her and she was going to be ok and that he'd be there soon to take care of her like always then she closed her eyes and she just died, I had to grab her stuff and the sad thing is she had her money in her coat for the taxi ride home it happened so fast and so suddenly, my grandfather died a week later at the same time and same day she did, he waited for her funeral and the next day he just layed down and passed away, wherever they are now I hope there together and happy`,
    "v": "NDHY1D0tKRA",
    "s": "I Will Follow You Into The Dark – Death Cab For Cutie",
    "t": "romantic"
  },
  {
    "c": `I still miss you Mia, you were my best friend and my first love. If only I got the chance to tell you how I felt before you pulled the plug. I remember how you asked me to stay alive for you during my suicidal days because I felt a deep emptiness, that was nothing compared to what I felt when you passed. I promised myself to stay alive to keep your memory burning bright, and I do not think negatively of you, nor will call you a hypocrite. You were so optimistic and saw the bright side of everything. I hate your ex boyfriend that beat you, I hate your parents for always bickering and neglecting you, and I hate the pills that took you from this world. But I love you for the art of forgiveness you taught me. I lost you before you were mine and all I want to do is see your face again and hear your voice, but the world had different plans. Nevertheless I love you and I know I’ll see you again one day but I’m gonna keep going not just because of the promise but for myself as well. This life is here because of you, thank you. Until we meet again`,
    "v": "NDHY1D0tKRA",
    "s": "I Will Follow You Into The Dark – Death Cab For Cutie",
    "t": "romantic"
  },
  {
    "c": `My Aurora,

Though we are both still alive, we are both unwell. There will come a time where one of us will pass and leave the other to carry on our legacy. This, our song, is what makes me believe that I will meet you again in the afterlife. That, though we may be separated for a short amount of time, I'll see you again. My arms are forever around you, holding you close. Though we may be sobbing, unstable humans, we are lovers. My soulmate, my Aurora, I love you so very much, and when the time dawns, I too will follow you into the dark.`,
    "v": "NDHY1D0tKRA",
    "s": "I Will Follow You Into The Dark – Death Cab For Cutie",
    "t": "romantic"
  },
  {
    "c": `Someone I considered really close to me and confided a lot in, walked away from my life. I am fully conscious of the fact that I made some mistakes but losing a friend that you invested so much into emotionally is hard. It's almost as if they take a part of you with them.

The memories almost seem unreal, a lifetime away and sometimes even dreamy. `,
    "v": "NDHY1D0tKRA",
    "s": "I Will Follow You Into The Dark – Death Cab For Cutie",
    "t": "romantic"
  },
  {
    "c": `This time of year is more sad than joyful as I remember the anniversaries of my parents' passing -- Mum passed 4 years ago; and Dad 2.

On the drive home this evening, I heard this song on the radio. I almost had to pull over; such emotions welled to the surface.

I miss Mum and Dad as much today as I did they day they passed. What I wouldn't give to hear one of Dad's jokes or taste some of Mum's cooking...

just...

one...

more...

time.`,
    "v": "NDHY1D0tKRA",
    "s": "I Will Follow You Into The Dark – Death Cab For Cutie",
    "t": "romantic"
  },
  {
    "c": `My fiance and I are going to use this as our first dance at our wedding in two months. I'm very sick and we honestly don't know how much more my body will take. But we aren't only using this song as a symbol of undying love. But also as undying sacrifice. A lot of bad luck has come my way and I always feel like if it wasn't for me, my fiancé would have a much better life. But he says I will always follow you into your darkest days and hardest hours. We have been through so much. We have been in the darkest part of our relationship, with sickness, job losses, pregnancy losses, and so much more. I have always loved this song, but I am so grateful that now there is so much meaning behind it for the both of us. `,
    "v": "NDHY1D0tKRA",
    "s": "I Will Follow You Into The Dark – Death Cab For Cutie",
    "t": "romantic"
  },
  {
    "c": `RIP Dad. It's been almost three years but I still miss you. 
I miss discussing obscure films and analyzing Floyd songs with you.
I miss visiting the book-fair and messing around the stalls with you, hunting for books. I went last year with a friend, but it just wasn't the same.
I wish you were there to see me get my first paycheck.

I hope you're proud of the person I've become.`,
    "v": "NDHY1D0tKRA",
    "s": "I Will Follow You Into The Dark – Death Cab For Cutie",
    "t": "romantic"
  },
  {
    "c": `i will never forget how you made me believe`,
    "v": "FWZrdB4RACQ",
    "s": "Even Fantastica – Flotation Toy Warning",
    "t": "longing"
  },
  {
    "c": `This Band was the love of my 23 year young son, who passed 3 weeks back in peace after a brave battle, now he is free and dancing so sweet in my house to this beautiful sound. There is no seperation, life is eternal and love is the source`,
    "v": "RBtlPT23PTM",
    "s": "Space Song – Beach House",
    "t": "longing"
  },
  {
    "c": `This song reminds me of my wife i had, i was born in 1979 and so was she, we lived next door to one another and known each other since we were born, we'd ride our bikes to school everyday together, basically sleep over at each others houses every night. In high school i asked her out, she screamed when i did and she started crying and i remember her saying "I've been waiting for you to ask, ive liked you since year 1". That night i drove her to the Drive Ins and we watched a movie. Counting Pre school and after high school and college we were together for over 35 years until 7 years ago she was diagnosed with stage 3 breast cancer, 6 months later she passed away while i was with her, i felt the coldness in her and it spread to me it sent goosebumps down my neck and the grip she had while holding my hand was lost and she whispered to me "thank you for all time we have had together". That night i cried and screamed so hard my body totally collapsed and i passed out. Today me and my kids listen to this song together (6) and (8) years old. I cry to sleep every night knowing that shes never coming back... I want to end it all meet her in heaven but i cant loose my kids and they cant lose me. Thank-you for this song everyday and almost every hour i listen to this and im reminded of her. I miss you Emma and I miss my soulmate, Emma I love you more then anything else in this universe and i wish you were still here with me.`,
    "v": "RBtlPT23PTM",
    "s": "Space Song – Beach House",
    "t": "longing"
  },
  {
    "c": `it makes me remember how much im loved. puts me back in place. makes me miss my dad who passed to covid. we werent close but i still loved him. and to this day miss him so much. i wish i could go back and fix things between us pops, i miss u, and i hope u know that i love you always`,
    "v": "RBtlPT23PTM",
    "s": "Space Song – Beach House",
    "t": "longing"
  },
  {
    "c": `I knew a girl from all the way back in third grade. We were close to best friends, and whenever I saw her she cheered me up. A few years later, the pandemic hit. We didn’t stay in touch over the pandemic, and when we came back I was so happy to see her. It was awkward at first but eventually we became good friends again. Then I started to realize something incredible. I loved her. Seeing her made my heart beat faster, her smile made me feel warm inside. I finally got the courage to confess my feelings to her one day. That morning I wrote her a love letter, putting all of my feelings for her in the form of words. I decided to hand it to her with high hopes. However, I learned that day that she didn’t care about me. She threw the letter away before even reading it for a second. Our friendship, all the memories we made, they’re all gone. It felt like a knife through my heart, and now whenever I say or do anything it just ruins everything. I don’t think anyone cares about me at this point. And I feel so, so, lost. All those times I spent with her and my friends on the playground, all those times I smiled without a care in the world. Gone.`,
    "v": "RBtlPT23PTM",
    "s": "Space Song – Beach House",
    "t": "longing"
  },
  {
    "c": `This song reminds me of a person who was close to me, we shared a lot of habits, one of which was messaging in a state of half sleep, we spoke our hearts out in that state, without a filter because the sleep would dull out all the anxiety and fear. We regularly spoke to each other on calls and slept while messaging each other. We had become more than friends but one day suddenly without any notice or even excuse they just distanced themselves from me. Suddenly it felt like the ground opened up under my feet and swallowed me whole. I asked them what happened where did I go wrong was it something I said and I always got the reply, I don't know but I just don't feel the same anymore. Humans change, I felt I never moved from that place untill I met my now wife, she really fills in the void, but I still can't forget that friend, that platonic love I had for her.`,
    "v": "RBtlPT23PTM",
    "s": "Space Song – Beach House",
    "t": "longing"
  },
  {
    "c": `
I love this song, even if it reminds me of how wrong a relationship can go… It’s  kinda sad, to realize you can be on somebody’s side, but still… there is no way in… or out of the woods together! The song is a master piece though. And just now, listening to it again, I can tell something about the song has changed. It feels different now…less sad. That’s so rewarding. Now I am actually glad things turned out the way they did… everything is perfect. My son was the biggest present. He shows me every day, what’s the real meaning of love.`,
    "v": "RBtlPT23PTM",
    "s": "Space Song – Beach House",
    "t": "longing"
  },
  {
    "c": `I will never forget the day my boyfriend introduced this song to me, I still get the same vibe and gut feeling whenever I listen to this. Rest in peace Denis`,
    "v": "4Hg1zIAh3rc",
    "s": "Reflections After Jane – The Clientele",
    "t": "longing"
  },
  {
    "c": `Reminds me of this day I spent with an old friend of mine. The first time it was just her and me. We went on an adventure. She showed me her hometown, her old house, a field full of sunflowers. I won't forget it. Ever.`,
    "v": "4Hg1zIAh3rc",
    "s": "Reflections After Jane – The Clientele",
    "t": "longing"
  },
  {
    "c": `I broke up with this girl I really love.`,
    "v": "4Hg1zIAh3rc",
    "s": "Reflections After Jane – The Clientele",
    "t": "longing"
  },
  {
    "c": `thinking of a time when I had feelings for someone.`,
    "v": "4Hg1zIAh3rc",
    "s": "Reflections After Jane – The Clientele",
    "t": "longing"
  },
  {
    "c": `when i listen to this i think about the times when i thought i fell in love. we were giving obvious signs that we like each other but then something went wrong?? thinking about it now that's maybe even better that we didn't become lovers
at least we are still friends.`,
    "v": "4Hg1zIAh3rc",
    "s": "Reflections After Jane – The Clientele",
    "t": "longing"
  },
  {
    "c": `I'm left to wonder if something, if anything, went wrong? I crave to see the moon high above the motorway again, a pale pink spreading slowly throughout the sky. To hear your words one more time.`,
    "v": "4Hg1zIAh3rc",
    "s": "Reflections After Jane – The Clientele",
    "t": "longing"
  },
  {
    "c": `I love you forever isiaha james, even if we never make it to the future together , you will always have my heart..🖤`,
    "v": "4Hg1zIAh3rc",
    "s": "Reflections After Jane – The Clientele",
    "t": "longing"
  },
  {
    "c": `The girl said no and I didn't sleep for three nights. I put this album on repeat nursing beer after beer. Who was once my best friend I haven't spoken to in two years. 

Don't you think we could pretend that friendships and love never end...?`,
    "v": "FaBnr-B2Xro",
    "s": "Friendships And Love – Rocketship",
    "t": "longing"
  },
  {
    "c": `sitting in Union Station at the end of summer and realizing that everything is going to change very soon.`,
    "v": "FaBnr-B2Xro",
    "s": "Friendships And Love – Rocketship",
    "t": "longing"
  },
  {
    "c": `I know its true...`,
    "v": "FaBnr-B2Xro",
    "s": "Friendships And Love – Rocketship",
    "t": "longing"
  },
  {
    "c": `The girl said no and I didn't sleep for three nights. I put this album on repeat nursing beer after beer. Who was once my best friend I haven't spoken to in two years. 

Don't you think we could pretend that friendships and love never end...?`,
    "v": "FaBnr-B2Xro",
    "s": "Friendships And Love – Rocketship",
    "t": "longing"
  },
  {
    "c": `The child who are inside us haven't faded away. He got lost in this adult world where life is so serious. Imagine yourself in front of you when you were a child and hug you, find yourself and love life for all that you can always make of it. No longer look at the past because it no longer exists, do not look at the future because it has not yet happened. Love yourself and make your life a dream of love or whatever you wish comes true.`,
    "v": "nDkkK-KHjks",
    "s": "Cannons – Youth Lagoon",
    "t": "longing"
  },
  {
    "c": `"I miss you more than I remember you"`,
    "v": "gPjqWwkAymg",
    "s": "All I've Ever Known – Bahamas",
    "t": "longing"
  },
  {
    "c": `"crying at 3am for u and i probably don’t even cross your mind."`,
    "v": "gPjqWwkAymg",
    "s": "All I've Ever Known – Bahamas",
    "t": "longing"
  },
  {
    "c": `"you’ll be okay, everything will be okay. just hang on tight for me, alright?`,
    "v": "gPjqWwkAymg",
    "s": "All I've Ever Known – Bahamas",
    "t": "longing"
  },
  {
    "c": `"I cried to this song, not that i've heartbroken before, but because i can. Im in a beatiful relationship with a soft person and i forget to appreciate sometimes what we have. I hear people breaking up after 3, 5 or 10 years and i think to myself, could it happen to me? These sad songs remind me not to take anything for granted, that there is always room to improve, to become a better version of yourself for the person you love and care about. I get reminded that one day, i could be listening to this song, and actually die inside, get my heart squeezed with the feelings cuz i'll be understanding it better. And i dont want that. So if u love someone and they love you, dont stop doing effort to make it better. Respect, loyalty and care are very important. Wont forget that."`,
    "v": "gPjqWwkAymg",
    "s": "All I've Ever Known – Bahamas",
    "t": "longing"
  },
  {
    "c": `"My dear friends. 

What a beautiful corner of the internet did I just discover.
It is so rare to hear so many people acknowledge openly that this life is hard and that we suffer. 
Just scrolling through the comments and reading the stuff people go through, makes it horribly and beautifully apparent that this is so. These comments are from people on the internet, names that point to people, we will likely never meet. But their stories are not individual cases. Not something that is rare. The people you know personally and you yourself have suffered. The intensity of the suffering and the depth of the wounds are not something that sets us apart. We are united in the fact that we love and in the fact that we suffer.

But I want this comment to be ray of sunshine, a slight touch of hope amidst this misery. I don't need to tell y'all why it sucks. You know that. You have lived in this world. We fall apart and what we love does too. This is a fundamental fact of life that needs to be acknowledged. This world is not shaped in a way as to be able to make us happy. Ever.

If you stay here and have only realised this, depression is the result. I acknowledge this and my heart is still not made of stone. 
Nonetheless, I am not depressed. I have found my peace with this way the world is, because I have found something higher than this world.
I am not going to tell you, what it is. Neither am I going to tell you, where I found it, other than: Within myself and all around us. I just want this to be a signpost, saying: There is a way out of this. Because there is. How are you going to find it? I don't know. People are too different for a solution that works for everybody. I know my way and I travelled far enough to be at rest. You are going to find your way, I am certain. 
There have been great souls, showing us various paths toward the Divine. Following a well trodden path is better, than making your own way.
Depression is not the end. It is the beginning of spirituality. The beginning of freedom.

Find that which lasts, in all this change. Everything in this world will disappoint you, but this will not.

I wish you all the best on your journey. I wish you all the peace, love and happiness you deserve.
You will get there one day. You will be free.

Until then, know that someone cares. Know that you are not alone in your suffering.
Read these comments and realise that suffering is a fundamental part of human life.
Beyond all our differences, we are united in love and suffering.

Let there be more love in this world and less suffering."`,
    "v": "gPjqWwkAymg",
    "s": "All I've Ever Known – Bahamas",
    "t": "longing"
  },
  {
    "c": `Fell in love with a man who wasn’t meant to be mine. `,
    "v": "gPjqWwkAymg",
    "s": "All I've Ever Known – Bahamas",
    "t": "longing"
  },
  {
    "c": `When I said I was going to wait for you, you begged me not to. 
But I didn’t listen and here I am, two years later, still looking for you in every song, in every single shred of life I have left.`,
    "v": "gPjqWwkAymg",
    "s": "All I've Ever Known – Bahamas",
    "t": "longing"
  },
  {
    "c": `I don't know why I think about you every morning when I wake up and every night before I go to sleep. We were not even close to being official, we were just strangers getting to know each other. Even knowing this you still live in my mind every single day for no good reason. You came into my life at a time where I thought that I wouldn't even consider a relationship but you seriously changed that. After our first date I seriously felt whole for the first time in so long. I felt capable and wanted. I know that you don't hate me and that our circumstances were just not good but I still think about you every single day wishing I could talk to you.`,
    "v": "gPjqWwkAymg",
    "s": "All I've Ever Known – Bahamas",
    "t": "longing"
  },
  {
    "c": `you're thinking of the person you love while you're listening to this and they dont even think about you`,
    "v": "gPjqWwkAymg",
    "s": "All I've Ever Known – Bahamas",
    "t": "longing"
  },
  {
    "c": `Could be worse, but damn does it suck.`,
    "v": "gPjqWwkAymg",
    "s": "All I've Ever Known – Bahamas",
    "t": "longing"
  },
  {
    "c": `When you found your soulmate but she can't and will never love you`,
    "v": "gPjqWwkAymg",
    "s": "All I've Ever Known – Bahamas",
    "t": "longing"
  },
  {
    "c": `I once met a person with a soul so bright that our short time together felt like a lifetime. May we meet again Julian.`,
    "v": "gPjqWwkAymg",
    "s": "All I've Ever Known – Bahamas",
    "t": "longing"
  },
  {
    "c": `i just want to tell you a real thank you. i'm listening this at my birthday all alone. i cried. i wished my biggest will and dream while listening to this song.`,
    "v": "gPjqWwkAymg",
    "s": "All I've Ever Known – Bahamas",
    "t": "longing"
  },
  {
    "c": `A few months back, I met an amazing and sweet girl where we always had deep conversations and then we expressed our music taste together and she told me about cigarettes after sex. We both listened to apocalypse together at 4am, It made me feel as if I was in a different world. I cannot begin to express the amazing feelings and emotions I had listening to this song. It makes me feel of my happy times filled with joy and living in the moment, especially being with her. Then feeling to hard times with heartbreak, feeling down, crying, healing, and to picking myself back up. Well, we stopped talking and parted ways. She was going through a lot and I hope shes doing well, I wish things worked out between us…but life happens. This song will always remain with me and I’ll always listen to CAS. These experiences becomes a memory, memories in which I’m forever grateful for.`,
    "v": "sElE_BfQ67s",
    "s": "Apocalypse – Cigarettes After Sex",
    "t": "longing"
  },
  {
    "c": `I just miss her a lot, i wish i could listen to this song with her while laying down in a huge field just looking at the moon and having our dumb talks about things that we absolutely love, or our stupid debates that we would always have. she was literally the light for my life but now she left me here in a really dark place`,
    "v": "sElE_BfQ67s",
    "s": "Apocalypse – Cigarettes After Sex",
    "t": "longing"
  },
  {
    "c": `I love my girlfriend, I was with her today and we were listening together while we smoked, the energy and the connection between us is strong, I really love her.`,
    "v": "sElE_BfQ67s",
    "s": "Apocalypse – Cigarettes After Sex",
    "t": "longing"
  },
  {
    "c": `
I recently lost my girlfriend. We were together for 6 full years. I wanted to write this because I felt it was necessary. I needed to get it off my chest. Everything was great in the first year. We had that spark when you meet someone new. Unfortunately, she had got out of a long term relationship from high school and had history with him. She cheated on me the first year. I forgave her because I really wanted to be with her, but to be honest. Ever since then, it went downhill. We had good times but mostly bad because it was in the back of my head for a long time until I got over it. It took me 2-3 years to get over that feeling of not being wanted or loved. I wanted to be perfect for her. Then 3 years into the relationship, we fought more and more and said things we didn’t mean and regret. She found someone else for like 1-2 months. So it sucked, that she basically cheated again because we weren’t done. When I found out she was with someone else. I saw her phone, pictures of her naked that were sent. Messages. It hurt like hell, and I didn’t know what I was doing wrong. Again, like an idiot. I forgave her and we started dating again. Then now that we made 6 years. She started feeling not happy anymore, all we did was fight. Quarantine didn’t make it any better. We rarely saw each other. I knew we were at the verge of a cliff. And it sucks. Because I caught her yet again 1 week ago. With her first ex from high school in the car. She looked dead at me. I knew in that moment. Everything was over and done with. She had moved on. The crazy thing about it, was I had just bought her a vase with roses that night and I was going to tell her that she was the one and that I was sorry for not trying anymore. That we could maybe start over. But after seeing something like that, it just kind of kills you. It breaks you in ways that I can’t describe. She didn’t even text me or call me after. She just left it like that. Everybody says I deserve better but it still hurts to lose someone you’ve been with for that long. I’m sorry for writing this. But cigarettes after sex has saved me. From pain and from loneliness because their music helps me calm down and makes me happy. Even though, she did indeed break my heart. I wish her nothing but the best and I hope she finds happiness. Now, I hope to just focus on myself and work hard to do what I want to do. I will keep you guys updated in 6 months-1 year to see how I am doing. Thank you for reading this.`,
    "v": "sElE_BfQ67s",
    "s": "Apocalypse – Cigarettes After Sex",
    "t": "longing"
  },
  {
    "c": `It reminds me of my recent ex, my first love, my dad who lives in another country, my friends, beautiful moments, painting/drawing, running or doing other sports, happy memories, sad memories, ... The list can go on. But most of all it reminds me of how unique each life is, how unique I am as a person, or how unique others are as a person.`,
    "v": "1aMQ8db4Y4c",
    "s": "Your Hand In Mine – Explosions in the Sky",
    "t": "longing"
  },
  {
    "c": `Kissed her in high school. Never forgot the feeling. Didn't see her for six years. She reappeared, visiting our hometown. I kissed her again, and it felt the same as it did years ago. We spent one night together, and the way the light came in across her face through the slats in the blinds and the way dust motes danced around her in the morning is still the most beautiful thing I've ever seen. It pains me to think I may never see her in my life again, but this song reminds me of those twenty four beautiful, perfect hours.`,
    "v": "1aMQ8db4Y4c",
    "s": "Your Hand In Mine – Explosions in the Sky",
    "t": "longing"
  },
  {
    "c": `Deployed right now... Imagining holding my 3 year old daughter and dancing with her... she's perfect.`,
    "v": "1aMQ8db4Y4c",
    "s": "Your Hand In Mine – Explosions in the Sky",
    "t": "longing"
  },
  {
    "c": `i rememberer playing this song as you slept. Maybe your were just enough awake to hear it. i wanted to hold you so bad on those nights when you were gone. You always wanted to be with me.

I remember when i held you that one night. Thinking that no one will, has, or will ever love me as much as you did. I know you still do. I miss you so much. It still feels like empty. It still hurts sometimes.`,
    "v": "1aMQ8db4Y4c",
    "s": "Your Hand In Mine – Explosions in the Sky",
    "t": "longing"
  },
  {
    "c": `Please God, I don't want to fail again. Please listen to me just this once. Please give me the strength to complete what I have  begun.`,
    "v": "1aMQ8db4Y4c",
    "s": "Your Hand In Mine – Explosions in the Sky",
    "t": "longing"
  },
  {
    "c": `This song was played at a concert that I attended with someone that I just ended a relationship of one year to the love of my life. She was my first in more ways than just intimacy and she was one of the most amazing, interesting, beautiful women I have ever met, I mean truly gorgeous. We clicked so well and had amazing chemistry and I am really gonna miss her, but she just could not envision me as a husband and we could no longer fight the facts. There were other issues and I did have some shortcomings but ultimately I realized after the breakup that you cant force a relationship and you and the other person deserve to be with someone who can see that future with each other. It doesn't mean they didn't care or didn't love you or didn't try. It just means they were not your person and vice versa. There will be that one in your life you loved more than anything but just because the feelings are there does not fix the underlying problems which we did try and work on.  I will always think of her and love her as a person with all my heart and I hope she lives a great life and maybe one day we will meet again in this life or the next.`,
    "v": "1aMQ8db4Y4c",
    "s": "Your Hand In Mine – Explosions in the Sky",
    "t": "longing"
  },
  {
    "c": `One of my best friends, when he got married. This was the song he choose when he stood waiting waiting for his wife to reach the end of the  aisle. This is the memory I get when I hear this song. I cried like a baby because I was so happy for them. I blame this song for helping setting a perfect mood for a happy occasion. 👌`,
    "v": "1aMQ8db4Y4c",
    "s": "Your Hand In Mine – Explosions in the Sky",
    "t": "longing"
  },
  {
    "c": `In case you are here to find a message from Universe: go to anybody who you love even though it might be the worst idea and tell them.`,
    "v": "DBQWF35bqDQ",
    "s": "WE Might Be Dead By Tomorrow – Soko",
    "t": "longing"
  },
  {
    "c": `My mom's friend passed away of lung cancer during the spring. This song makes me think of her. We might not have had too many memories together, but the one's we did have were very great. I never got to see her before she passed.`,
    "v": "DBQWF35bqDQ",
    "s": "WE Might Be Dead By Tomorrow – Soko",
    "t": "longing"
  },
  {
    "c": `This song is for the one I love, for that one friend i hope I'll stay with forever and for the people i haven't met yet`,
    "v": "DBQWF35bqDQ",
    "s": "WE Might Be Dead By Tomorrow – Soko",
    "t": "longing"
  },
  {
    "c": `This song hits different now. I lost my grandmother to COVID. I lost my grandmother without saying goodbye, and my mother lost her mother without saying goodbye.`,
    "v": "DBQWF35bqDQ",
    "s": "WE Might Be Dead By Tomorrow – Soko",
    "t": "longing"
  },
  {
    "c": `I cannot love someone as that, even if I thought I can. People who can love back to their lover, are really deserve to be loved.`,
    "v": "DBQWF35bqDQ",
    "s": "WE Might Be Dead By Tomorrow – Soko",
    "t": "longing"
  },
  {
    "c": `Love is all that matters`,
    "v": "DBQWF35bqDQ",
    "s": "WE Might Be Dead By Tomorrow – Soko",
    "t": "longing"
  },
  {
    "c": `I wish I could tell him I love him.`,
    "v": "NZlXwPb_JPM",
    "s": "Bluish – Animal Collective",
    "t": "longing"
  },
  {
    "c": `shoutout to my ex for ruining this song for me

EDIT: I have come to realize that she did not “ruin this song for me” like I wrote. She actually gave so much more meaning to this than I initially understood. Because, I have so many feelings tied to this song, it was hard to relinquish those feelings while I listened to it. Now, with more clarity, I can just enjoy it the same as when I did with her. I have many other songs that remind me of people, this is one of the stronger more surface level ones that resonate the clearest. ... anyway, just enjoy the song. Peace.`,
    "v": "NZlXwPb_JPM",
    "s": "Bluish – Animal Collective",
    "t": "longing"
  },
  {
    "c": `I got lost in her curls and now my world shimmers and glows with love.`,
    "v": "NZlXwPb_JPM",
    "s": "Bluish – Animal Collective",
    "t": "longing"
  },
  {
    "c": `This sounds like what love feels like.`,
    "v": "NZlXwPb_JPM",
    "s": "Bluish – Animal Collective",
    "t": "longing"
  },
  {
    "c": `I distinctly remember my parents driving me to our new house while this song was playing. I was 15 and I was crying through my bangs that covered my eyes. I love where I am now and I am grateful for the memory.`,
    "v": "82xcICYq11Y",
    "s": "I'd Like To Walk Around In Your Mind – Vashti Bunyan",
    "t": "longing"
  },
  {
    "c": `this song reminds me of the time i did acid with a friend and everything he said was so beautiful and smart that i just kept thinking i wish i could live in his head`,
    "v": "82xcICYq11Y",
    "s": "I'd Like To Walk Around In Your Mind – Vashti Bunyan",
    "t": "longing"
  },
  {
    "c": `I distinctly remember my parents driving me to our new house while this song was playing. I was 15 and I was crying through my bangs that covered my eyes. I love where I am now and I am grateful for the memory.`,
    "v": "82xcICYq11Y",
    "s": "I'd Like To Walk Around In Your Mind – Vashti Bunyan",
    "t": "longing"
  },
  {
    "c": `Reminds me that there is still love in the world.`,
    "v": "82xcICYq11Y",
    "s": "I'd Like To Walk Around In Your Mind – Vashti Bunyan",
    "t": "longing"
  },
  {
    "c": `Today me and my girlfriend agreed that this would be our song. It's beautiful.`,
    "v": "82xcICYq11Y",
    "s": "I'd Like To Walk Around In Your Mind – Vashti Bunyan",
    "t": "longing"
  },
  {
    "c": `This was my dad's favourite song. We played this for his funeral, I still remember him.`,
    "v": "82xcICYq11Y",
    "s": "I'd Like To Walk Around In Your Mind – Vashti Bunyan",
    "t": "longing"
  },
  {
    "c": `I found this song when I was in love. Now hearing it again, the warmth and longing is gone. I can’t understand the words anymore. I’m listening trying to find that feeling but it was a lie. It was all a lie.`,
    "v": "82xcICYq11Y",
    "s": "I'd Like To Walk Around In Your Mind – Vashti Bunyan",
    "t": "longing"
  },
  {
    "c": `This song reminds me of a person I dated, they struggled with mental health quite severally and I would always tell them how proud and how amazing they where we sat in a field for hours talking about life and how we want to grow old together. unfortunately they passed away last month and I come here every so often just to be reminded of them I know there still with me because I can feel there presence behind me while I listen, it’s quite fascinating`,
    "v": "82xcICYq11Y",
    "s": "I'd Like To Walk Around In Your Mind – Vashti Bunyan",
    "t": "longing"
  },
  {
    "c": `I like to imagine that this is what falling in love sounds like.`,
    "v": "kIu-eevvg_A",
    "s": "Irresistible – Deafheaven",
    "t": "longing"
  },
  {
    "c": `My wife and I recently celebrated our 23rd anniversary together. I sent her a compilation video of my favourite photos of us together, spanning all those years. 9 months ago, she was diagnosed with incurable metastatic breast cancer; adding this song to our photos created a beauty and poignancy that will stay with me forever as I revisit the video long after she has gone. It is a hard listen but I will always associate this song with her, because to me, she is Irresistible.`,
    "v": "kIu-eevvg_A",
    "s": "Irresistible – Deafheaven",
    "t": "longing"
  },
  {
    "c": `I feel something, but I don't know how to describe it`,
    "v": "kIu-eevvg_A",
    "s": "Irresistible – Deafheaven",
    "t": "longing"
  },
  {
    "c": `Reminds me of slow dancing with my girlfriend when we decided to break up.`,
    "v": "kIu-eevvg_A",
    "s": "Irresistible – Deafheaven",
    "t": "longing"
  },
  {
    "c": `Thank you for the beautiful years we had together. I will always remember you`,
    "v": "kIu-eevvg_A",
    "s": "Irresistible – Deafheaven",
    "t": "longing"
  },
  {
    "c": `I used to listen to this song in late 1966 with my girlfriend, when we were both students at UCLA. It was "our song". We were happy.The following year, as a young Army lieutenant, I was sent to fight in Vietnam and my life changed forever. Those days and my girlfriend are long gone but this wonderful song always reminds me of that time and still brings a tear to my eye. `,
    "v": "AOMyS78o5YI",
    "s": "God Only Knows – The Beach Boys",
    "t": "longing"
  },
  {
    "c": `My wonderful wife Chrissy died Feb 19, 2021. I dedicate this song to our almost 48 years of earthly marriage. We’ll be together for eternity, this I know for sure.`,
    "v": "AOMyS78o5YI",
    "s": "God Only Knows – The Beach Boys",
    "t": "longing"
  },
  {
    "c": `Our dad who just left us played the French Horn for over 85 years and hearing the intro brings me to tears every time. Heavens band must be glorious! No better song ever written or recorded.`,
    "v": "AOMyS78o5YI",
    "s": "God Only Knows – The Beach Boys",
    "t": "longing"
  },
  {
    "c": `"Our song" between me and my incredibly precious daughter. God truly only knows. I love her beyond meaning.`,
    "v": "AOMyS78o5YI",
    "s": "God Only Knows – The Beach Boys",
    "t": "longing"
  },
  {
    "c": `Listening to this while on a walk along the beach and realizing this is the theme song for literally everyone I look at. Everyone's here with family and they're all smiling and laughing. This is their song -- they just don't know it.`,
    "v": "AOMyS78o5YI",
    "s": "God Only Knows – The Beach Boys",
    "t": "longing"
  },
  {
    "c": `I dedicate this to all of you who feel this way but find it difficult to express... unspoken love.`,
    "v": "AOMyS78o5YI",
    "s": "God Only Knows – The Beach Boys",
    "t": "longing"
  },
  {
    "c": `I fell in love to this album for the first time, the music brings it back`,
    "v": "0itGqFgY4ts",
    "s": "Lover's Spit – Broken Social Scene",
    "t": "longing"
  },
  {
    "c": `Listening to this while talking to the moon in my head. I was all wrong about it, he is very much appreciated`,
    "v": "0itGqFgY4ts",
    "s": "Lover's Spit – Broken Social Scene",
    "t": "longing"
  },
  {
    "c": `This is what the penultimate love of your life will share with you…`,
    "v": "0itGqFgY4ts",
    "s": "Lover's Spit – Broken Social Scene",
    "t": "longing"
  },
  {
    "c": `Sing to me every day. Thank you.`,
    "v": "0itGqFgY4ts",
    "s": "Lover's Spit – Broken Social Scene",
    "t": "longing"
  },
  {
    "c": `I think I'm gonna go for it.`,
    "v": "0itGqFgY4ts",
    "s": "Lover's Spit – Broken Social Scene",
    "t": "longing"
  },
  {
    "c": `One thing doesn't make a man.`,
    "v": "0itGqFgY4ts",
    "s": "Lover's Spit – Broken Social Scene",
    "t": "longing"
  },
  {
    "c": `I want em back.`,
    "v": "0itGqFgY4ts",
    "s": "Lover's Spit – Broken Social Scene",
    "t": "longing"
  },
  {
    "c": `this song played in the cafe after i got stood up, felt like fate`,
    "v": "4LLIJkP301E",
    "s": "Call It Fate, Call It Karma – The Strokes",
    "t": "longing"
  },
  {
    "c": `I met a beautiful girl at a festival and took her to my house. I always wanted to share this song in a deep way. So, we listened to this song with high quality over the head phones together(on acid.) We started dancing, and suddenly we were kissing... and then one of the best moments of my life. I hold this song so close to me.`,
    "v": "4LLIJkP301E",
    "s": "Call It Fate, Call It Karma – The Strokes",
    "t": "longing"
  },
  {
    "c": `I haven't been in love for a few years.`,
    "v": "4LLIJkP301E",
    "s": "Call It Fate, Call It Karma – The Strokes",
    "t": "longing"
  },
  {
    "c": `this was our song, he said he'd stand in my light forever then chose someone else over me`,
    "v": "4LLIJkP301E",
    "s": "Call It Fate, Call It Karma – The Strokes",
    "t": "longing"
  },
  {
    "c": `I want to slow dance to this with someone special. Just once.`,
    "v": "4LLIJkP301E",
    "s": "Call It Fate, Call It Karma – The Strokes",
    "t": "longing"
  },
  {
    "c": `I sometimes wish you weren't attached to every memory or thought...`,
    "v": "4LLIJkP301E",
    "s": "Call It Fate, Call It Karma – The Strokes",
    "t": "longing"
  },
  {
    "c": `Memories of driving home with my husband after a long day out. We were driving along a motorway late at night with the cool night air flowing in through the open windows and listening to this beautiful, beautiful song on the radio. Rest in peace, David.`,
    "v": "OtBHfxU2wmc",
    "s": "I'm Not in Love – 10CC",
    "t": "longing"
  },
  {
    "c": `Memories of driving home with my husband after a long day out. We were driving along a motorway late at night with the cool night air flowing in through the open windows and listening to this beautiful, beautiful song on the radio. Rest in peace, David.`,
    "v": "OtBHfxU2wmc",
    "s": "I'm Not in Love – 10CC",
    "t": "longing"
  },
  {
    "c": `Why does this song hurts so bad even if I´m not in love?`,
    "v": "OtBHfxU2wmc",
    "s": "I'm Not in Love – 10CC",
    "t": "longing"
  },
  {
    "c": `It's 1975, I'm a teenager again, experiencing my first love and my first broken heart.  It is amazing how music can take us back to that time, those places, and the memories that stay with us our whole life....`,
    "v": "OtBHfxU2wmc",
    "s": "I'm Not in Love – 10CC",
    "t": "longing"
  },
  {
    "c": `I cry every time I listen to this, thinking of the past years of my childhood. My brother, sister, my dad and I would always be on car rides as far as I can remember, driving around at night usually on vacation or sometimes even just going to Sam's to buy groceries. But my dad had a CD of a bunch of really good songs that touched on me and stirred my taste for music as of now. I thank my dad so much for giving me a song to look back at and think of, I'm crying right now just typing this lol but I'm so happy that he gave me this music when I was younger. Now that times are a lot harder, this song is something to take me back to when everything was so simple and I didn't have to worry about how things would turn out tomorrow or what would happen to someone around me. `,
    "v": "OtBHfxU2wmc",
    "s": "I'm Not in Love – 10CC",
    "t": "longing"
  },
  {
    "c": `When you're in love, but you don't want to recognize it.`,
    "v": "OtBHfxU2wmc",
    "s": "I'm Not in Love – 10CC",
    "t": "longing"
  },
  {
    "c": `I was adopted since birth but I was 11 when I first heard this song and was just rescued from a bad foster home where I was badly abused and boy oh boy this song hit me so hard it always brings tears to my eyes when I hear it I love this song so much and it means the world to me`,
    "v": "NdYWuo9OFAw",
    "s": "Iris – Goo Goo Dolls",
    "t": "longing"
  },
  {
    "c": `Not many people can understand this… my son makes me feel this way. He left this world to be an angel and I just want him to know I loved him more than life itself. I would give up forever to hug him again.`,
    "v": "NdYWuo9OFAw",
    "s": "Iris – Goo Goo Dolls",
    "t": "longing"
  },
  {
    "c": `Remember when a just met my misses at 17  and were on the phone to each and other and this song was playing in the background and ever since that the song has always stuck with us it will be our wedding song and our funeral song takes me back to that day everytime I hear it😍  feels  like yesterday a just met her 11 years on with 3 beautiful kids and still going strong ❤`,
    "v": "NdYWuo9OFAw",
    "s": "Iris – Goo Goo Dolls",
    "t": "longing"
  },
  {
    "c": `I miss them so much and even if they are probably happier in this other world I can't stop myself from being selfish and wanting to spend a little more time with them`,
    "v": "NdYWuo9OFAw",
    "s": "Iris – Goo Goo Dolls",
    "t": "longing"
  },
  {
    "c": `My wife walked down to this song at our wedding 10 years ago. This song means so much to both of us.`,
    "v": "NdYWuo9OFAw",
    "s": "Iris – Goo Goo Dolls",
    "t": "longing"
  },
  {
    "c": `Music is one of the few things that can bring people together, and we must cherish that fact`,
    "v": "NdYWuo9OFAw",
    "s": "Iris – Goo Goo Dolls",
    "t": "longing"
  },
  {
    "c": `one time when i was 15 i was up late working on an essay for school, exhausted and stressed and crying, and my dad came in around midnight to say he was going to bed and i basically said whatever just leave me alone and then he came back with a bowl of strawberries he sprinkled some sugar over before saying good night. this song feels like that little bowl of sweet strawberries he gave me late at night.`,
    "v": "2RRrzssFlKw",
    "s": "TALKING – Haruomi Hosono",
    "t": "longing"
  },
  {
    "c": `Last week a friend visited me. She's half Swedish, half Portuguese, but we first met in Belgium a couple of years ago. I live in Holland now, so she drove two days by bike from Belgium to my place. 

On the second day of her visit, we found a green parrot lying on its back in front of my house, breathing heavily, and looking awful. These green tropical parakeets rule the air in our Dutch neighborhood, they once got released by families (or by a Zoo in Amsterdam, so another story goes) but somehow succeeded in surviving the northern climate. My friend carefully picked it up with her both hands, the little thing looked like it had been fiercely attacked. It soon died in her hands. 

We carefully put it in a cardboard box filled with leaves, and later buried it underneath a tree in the park nearby, next to a raspberriebush that my foraging friend found. As a ceremony, my friend read out loud all the song-titles we came up with the past years and that she keeps in a list on her phone, for our not-yet-existing band. It was meant as a joke, but when she read the last title ("support your local parrot") I started crying. 

During this entire  funeral we had my mobile phone playing this first song in the background, "Talking" by Haruomi Hosono, from this exact YouTube-video. 

I hope you all have a beautiful day, and a beautiful night.`,
    "v": "2RRrzssFlKw",
    "s": "TALKING – Haruomi Hosono",
    "t": "longing"
  },
  {
    "c": `one time when i was 15 i was up late working on an essay for school, exhausted and stressed and crying, and my dad came in around midnight to say he was going to bed and i basically said whatever just leave me alone and then he came back with a bowl of strawberries he sprinkled some sugar over before saying good night. this song feels like that little bowl of sweet strawberries he gave me late at night.`,
    "v": "2RRrzssFlKw",
    "s": "TALKING – Haruomi Hosono",
    "t": "longing"
  },
  {
    "c": `You are a young bamboo shoot. It's finally spring. Peeking up just above the ground, you're seeing the sun for the first time. Dew drops decorate your surroundings, reflecting its light with a crystal-like brilliance. Birds fly overhead, birds of all colours and shapes. You hear them sing, their melodies harmonising with the excited chatter of the cicadas, ringing in the new season. You absorb all of this life and beauty, giving you the strength to grow tall and become a part of the harmony that surrounds you. You are happy.`,
    "v": "2RRrzssFlKw",
    "s": "TALKING – Haruomi Hosono",
    "t": "longing"
  },
  {
    "c": `My childhood dog, Speedy,  just passed away. I came here immediately. 
I watched his birth,
We watched each other grow.
He was more of a "speed bump" than a Speedy;
until he got the zooms.
Last night, The Puppy Princess took him away when we weren't looking.
He laid by the front door (I assume) in hopes to go outside one last time. 
He was a good boy..`,
    "v": "2RRrzssFlKw",
    "s": "TALKING – Haruomi Hosono",
    "t": "longing"
  },
  {
    "c": `I'm 7 years old, laying in my bed and reading my favorite book. It is a Saturday afternoon and my mother is making spaghetti for dinner. I curl further into the bedsheets and feel as the cool mattress gradually heats under my body. I am warm and safe and loved, and I don't know what an e-mail is.`,
    "v": "2RRrzssFlKw",
    "s": "TALKING – Haruomi Hosono",
    "t": "longing"
  },
  {
    "c": `This song made me write this poem:
Today I bought you a slice of sun 
So that you could let me stare into your soul
Each mind is a universe
Yours is the one I want to live in 
Am I only dreaming? 
The wind brings me your smell 
From the mountains I have never seen
From the bridges I've never crossed
Today is a beautiful day to be sad 
Over and over again
Won't you taste your slice of sun?`,
    "v": "2RRrzssFlKw",
    "s": "TALKING – Haruomi Hosono",
    "t": "longing"
  },
  {
    "c": `Just broke off a five year relationship. We’re on good terms but Im feeling profoundly lonely. The house is near silent with all but this album along with these comments keeping me company and telling me it’ll be alright, even if it’s in a  bittersweet way. I’m in a weird spot at the moment, I’m planning on returning to college after a brief and spectacular failure of a semester in fall of 2019 (just before the pandemic hit lol). Feeling really anxious about that but a (rather optimistic) part of me is reassured that I’ll be okay though. Something tells me I’m going to be returning to this album a lot in the coming months. Thank you if you’ve read all this rambling, it means a lot.`,
    "v": "2RRrzssFlKw",
    "s": "TALKING – Haruomi Hosono",
    "t": "longing"
  }
];
